#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_netif.h"

#define MAX_APs 20
static const char *TAG = "WiFiScanner";

void wifi_scan_task(void *pvParameters)
{
    wifi_scan_config_t scan_config = {
        .ssid = 0,
        .bssid = 0,
        .channel = 0,
        .show_hidden = true
    };

    while (1) {
        ESP_ERROR_CHECK(esp_wifi_scan_start(&scan_config, true));

        uint16_t number = MAX_APs;
        wifi_ap_record_t ap_info[MAX_APs];
        ESP_ERROR_CHECK(esp_wifi_scan_get_ap_records(&number, ap_info));

        printf("\n%-4s %-32s %-6s %-4s %-10s\n", "Nr", "SSID", "RSSI", "CH", "Encrypt");
        for (int i = 0; i < number; i++) {
            char *authmode;
            switch (ap_info[i].authmode) {
                case WIFI_AUTH_OPEN: authmode = "OPEN"; break;
                case WIFI_AUTH_WEP: authmode = "WEP"; break;
                case WIFI_AUTH_WPA_PSK: authmode = "WPA_PSK"; break;
                case WIFI_AUTH_WPA2_PSK: authmode = "WPA2_PSK"; break;
                case WIFI_AUTH_WPA_WPA2_PSK: authmode = "WPA_WPA2"; break;
                case WIFI_AUTH_WPA3_PSK: authmode = "WPA3_PSK"; break;
                default: authmode = "UNKNOWN";
            }

            printf("%-4d %-32s %-6d %-4d %-10s\n",
                   i + 1,
                   (char *)ap_info[i].ssid,
                   ap_info[i].rssi,
                   ap_info[i].primary,
                   authmode);
        }

        vTaskDelay(pdMS_TO_TICKS(10000));
    }
}

void app_main(void)
{
    ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());

    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));
    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_start());

    xTaskCreate(wifi_scan_task, "wifi_scan_task", 4096, NULL, 5, NULL);
}
